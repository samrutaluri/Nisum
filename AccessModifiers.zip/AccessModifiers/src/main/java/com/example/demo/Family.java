package com.example.demo;

public class Family {
    // public variable
    public int HeadCount;

    // public method
    public void display() {
       
        System.out.println("HeadCount");
    }

}
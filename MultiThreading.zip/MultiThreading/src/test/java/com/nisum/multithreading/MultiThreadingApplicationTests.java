package com.nisum.multithreading;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiThreadingApplicationTests {

	@Test
	void contextLoads() {
	}

}

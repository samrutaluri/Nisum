package com.nisum.exception;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Exceptions {

	public static void main(String[] args) throws Exception {

		Object nullObject = null;
		try {
			System.out.println(nullObject.toString());
		} catch (NullPointerException npe) {
			System.out.println(npe);
		}

		int[] intArray = { 0, 1, 2 };
		try {
			System.out.println(intArray[3]);
		} catch (ArrayIndexOutOfBoundsException aie) {
			System.out.println(aie);
		}

		try {
			System.out.println(1 / 0);
		} catch (ArithmeticException ae) {
			System.out.println(ae);
		}

		Scanner scanner = new Scanner(System.in);
		try {
			System.out.print("Enter an integer: ");
			int number = scanner.nextInt();
			System.out.println("The number entered is " + number);

		} catch (InputMismatchException ex) {
			System.out.println("Incorrect input: an integer is required");
		}

		try {
			throwAnException();
		} catch (IllegalArgumentException e) {

			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String line = readFirstLine("imaginary-file");
		System.out.println(line);
	}

	private static void throwAnException() throws Exception {

		int r = new Random().nextInt(3);
		if (r == 0) {
			throw new IllegalArgumentException();
		} else if (r == 1) {
			throw new NullPointerException();
		} else if (r == 2) {
			throw new Exception();
		}
	}

	private static String readFirstLine(String fileName) throws IOException {
		File file = new File(fileName);
		Scanner fileReader = null;
		try {
			fileReader = new Scanner(file);
			return fileReader.nextLine();
		} catch (NullPointerException e) {
			throw new IOException("Bad filename.");
		} catch (FileNotFoundException e) {
			throw new IOException("Missing file.");
		} finally {
			if (fileReader != null) {
				fileReader.close();
			}
		}
	}

}